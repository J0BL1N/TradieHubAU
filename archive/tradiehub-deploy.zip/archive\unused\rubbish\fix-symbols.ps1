$replacements = @{
    "â€¢" = "•"
    "Â©" = "©"
    "â€”" = "—"
    "âœ…" = "✅"
    "â˜…" = "★"
    "â€“" = "–"
    "â€œ" = "“"
    "â€”" = "—"
    "â€˜" = "‘"
    "â€™" = "’"
    "â€¦" = "…"
    "â†’" = "→"
}

$files = Get-ChildItem -Recurse -Include *.html, *.js, *.css

foreach ($file in $files) {
    $content = Get-Content -Path $file.FullName -Raw -Encoding UTF8
    $changed = $false
    
    foreach ($bad in $replacements.Keys) {
        if ($content -contains $bad -or $content.Contains($bad)) {
            $content = $content.Replace($bad, $replacements[$bad])
            $changed = $true
        }
    }
    
    if ($changed) {
        Write-Host "Fixed: $($file.FullName)"
        Set-Content -Path $file.FullName -Value $content -Encoding UTF8
    }
}

Write-Host "Symbol fix complete."
