$port = 8080
$root = "$PSScriptRoot"
$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Any, $port)
$listener.Start()

Write-Host "Server running at http://localhost:$port/"
Write-Host "Press Ctrl+C to stop."

while ($true) {
    if ($listener.Pending()) {
        $client = $listener.AcceptTcpClient()
        $stream = $client.GetStream()
        $buffer = New-Object byte[] 4096
        $bytesRead = $stream.Read($buffer, 0, $buffer.Length)
        $request = [System.Text.Encoding]::ASCII.GetString($buffer, 0, $bytesRead)
        
        # Parse request line
        $requestLine = $request.Split("`r`n")[0]
        $parts = $requestLine.Split(" ")
        $method = $parts[0]
        $url = $parts[1]
        
        if ($url -eq "/") { $url = "/index.html" }
        $url = $url.Split("?")[0] # Strip query strings
        
        $path = "$root$url"
        $path = $path -replace "/", "\"
        
        if (Test-Path $path) {
            $content = [System.IO.File]::ReadAllBytes($path)
            $contentType = "text/html"
            if ($path.EndsWith(".css")) { $contentType = "text/css" }
            if ($path.EndsWith(".js")) { $contentType = "application/javascript" }
            if ($path.EndsWith(".png")) { $contentType = "image/png" }
            if ($path.EndsWith(".jpg")) { $contentType = "image/jpeg" }
            
            $header = "HTTP/1.1 200 OK`r`nContent-Type: $contentType`r`nContent-Length: $($content.Length)`r`nConnection: close`r`n`r`n"
            $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($header)
            $stream.Write($headerBytes, 0, $headerBytes.Length)
            $stream.Write($content, 0, $content.Length)
        }
        else {
            $response = "HTTP/1.1 404 Not Found`r`nContent-Length: 0`r`n`r`n"
            $responseBytes = [System.Text.Encoding]::ASCII.GetBytes($response)
            $stream.Write($responseBytes, 0, $responseBytes.Length)
        }
        
        $client.Close()
    }
    Start-Sleep -Milliseconds 10
}
