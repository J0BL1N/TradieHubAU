const fs = require('fs');
const path = require('path');

const rootDir = __dirname;
const extensions = ['.html', '.js', '.css'];

const replacements = [
    { bad: /â€¢/g, good: '•' },
    { bad: /Â©/g, good: '©' },
    { bad: /â€”/g, good: '—' },
    { bad: /âœ…/g, good: '✅' },
    { bad: /â˜…/g, good: '★' },
    { bad: /â€“/g, good: '–' },
    { bad: /â€œ/g, good: '“' },
    { bad: /â€/g, good: '”' },
    { bad: /â€˜/g, good: '‘' },
    { bad: /â€™/g, good: '’' },
    { bad: /â€¦/g, good: '…' },
    { bad: /â†’/g, good: '→' }
];

function walk(dir) {
    const files = fs.readdirSync(dir);
    files.forEach(file => {
        const fullPath = path.join(dir, file);
        const stats = fs.statSync(fullPath);
        if (stats.isDirectory()) {
            if (file !== 'node_modules' && file !== '.git') {
                walk(fullPath);
            }
        } else if (extensions.includes(path.extname(file))) {
            fixFile(fullPath);
        }
    });
}

function fixFile(filePath) {
    let content = fs.readFileSync(filePath, 'utf8');
    let changed = false;

    replacements.forEach(rep => {
        if (rep.bad.test(content)) {
            content = content.replace(rep.bad, rep.good);
            changed = true;
        }
    });

    if (changed) {
        console.log(`Fixed: ${filePath}`);
        fs.writeFileSync(filePath, content, 'utf8');
    }
}

walk(rootDir);
console.log('Symbol fix complete.');
