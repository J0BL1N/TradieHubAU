
import { getJobById, createProposal, getProposalsForJob, updateProposalStatus, updateJob } from '../core/db.js';

/**
 * Job Details Modal Component
 */
window.ATHJobDetails = window.ATHJobDetails || (function() {
    
    let currentJob = null;
    let currentUser = null;
    let modalEl = null;

    function init() {
        if (document.getElementById('athJobModal')) return; // Already exists
        
        // Inject Modal HTML
        const modalHtml = `
        <div id="athJobModal" class="fixed inset-0 z-[100] hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
            <!-- Backdrop -->
            <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onclick="window.ATHJobDetails.close()"></div>

            <div class="fixed inset-0 z-10 w-screen overflow-y-auto">
                <div class="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                    
                    <div class="relative transform overflow-hidden rounded-lg bg-white dark:bg-gray-800 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-2xl">
                        
                        <!-- Header -->
                        <div class="bg-gray-50 dark:bg-gray-700/50 px-4 py-3 sm:px-6 flex justify-between items-start">
                            <h3 class="text-base font-semibold leading-6 text-gray-900 dark:text-white" id="modal-title">Job Details</h3>
                            <button type="button" class="text-gray-400 hover:text-gray-500" onclick="window.ATHJobDetails.close()">
                                <span class="sr-only">Close</span>
                                <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>

                        <!-- Content -->
                        <div class="px-4 py-4 sm:p-6" id="athJobModalContent">
                            <div class="animate-pulse space-y-4">
                                <div class="h-4 bg-gray-200 rounded w-3/4"></div>
                                <div class="h-4 bg-gray-200 rounded w-1/2"></div>
                                <div class="h-32 bg-gray-200 rounded"></div>
                            </div>
                        </div>

                        <!-- Footer / Actions -->
                        <div class="bg-gray-50 dark:bg-gray-700/50 px-4 py-3 sm:flex sm:flex-row-reverse sm:px-6" id="athJobModalActions">
                            <!-- Buttons injected here -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        modalEl = document.getElementById('athJobModal');
    }

    async function open(jobId) {
        init();
        modalEl.classList.remove('hidden');
        
        // Loading state
        document.getElementById('athJobModalContent').innerHTML = `
            <div class="animate-pulse space-y-4">
               <div class="h-6 bg-gray-200 rounded w-1/3"></div>
               <div class="h-4 bg-gray-200 rounded w-2/3"></div> 
               <div class="h-32 bg-gray-200 rounded"></div>
            </div>`;
        document.getElementById('athJobModalActions').innerHTML = '';

        try {
            // 1. Fetch Job
            const { data: job, error } = await getJobById(jobId);
            if (error || !job) throw new Error('Job not found');
            currentJob = job;

            // 2. Get Current User (if any)
            const session = window.ATHAuth?.getSession?.();
            if (session?.userId) {
                // If we don't have full user obj, fetch basic profile?
                // ATHAuth.getCurrentUser() is async.
                const { user } = await window.ATHAuth.getCurrentUser();
                currentUser = user; 
            } else {
                currentUser = null;
            }

            // 3. Render
            render();

        } catch (err) {
            console.error(err);
            document.getElementById('athJobModalContent').innerHTML = `<div class="text-red-500 text-center py-8">Failed to load job details.</div>`;
        }
    }

    function close() {
        if (modalEl) modalEl.classList.add('hidden');
    }

    async function render() {
        const content = document.getElementById('athJobModalContent');
        const actions = document.getElementById('athJobModalActions');
        
        const job = currentJob;
        const isOwner = currentUser && (currentUser.id === job.customer_id);
        const isTradie = currentUser && (currentUser.role === 'tradie' || currentUser.role === 'dual');
        
        // --- CONTENT RENDER ---
        let html = `
            <div class="mb-6">
                <h2 class="text-2xl font-bold text-gray-900 dark:text-white mb-2">${escapeHtml(job.title)}</h2>
                <div class="flex flex-wrap gap-2 text-sm text-gray-500 mb-4">
                    <span class="flex items-center gap-1"><i data-feather="map-pin" class="w-4 h-4"></i> ${escapeHtml(job.location || job.suburb || 'Location')}</span>
                    <span class="flex items-center gap-1"><i data-feather="dollar-sign" class="w-4 h-4"></i> Budget: $${job.budget_max || job.budget_min || 'Any'}</span>
                    <span class="flex items-center gap-1"><i data-feather="clock" class="w-4 h-4"></i> ${job.urgency}</span>
                    <span class="px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-semibold uppercase tracking-wide">${job.status.replace('_', ' ')}</span>
                </div>
                
                <div class="prose dark:prose-invert max-w-none text-gray-700 dark:text-gray-300">
                    <p class="whitespace-pre-line">${escapeHtml(job.description)}</p>
                </div>
            </div>
        `;
        
        // Images (?)
        // if (job.images && job.images.length)...

        // SECTION: Proposals
        if (isOwner) {
            html += `<hr class="my-6 border-gray-200 dark:border-gray-700">`;
            html += `<h3 class="font-bold text-lg mb-4">Received Quotes</h3>`;
            html += `<div id="athJobProposalsList" class="space-y-3"><div class="text-sm text-gray-500">Loading quotes...</div></div>`;
            // Fetch async
            loadProposalsForOwner(job.id);
        } else if (isTradie && job.status === 'open') {
             // Check if already applied? 
             // We'd need to fetch proposals by ME for this job.
             // For simplicity, we'll just show the form.
             html += `<hr class="my-6 border-gray-200 dark:border-gray-700">`;
             html += `<h3 class="font-bold text-lg mb-4">Submit a Quote</h3>`;
             html += `
                <form id="athProposalForm" class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Price Estimate ($)</label>
                        <input type="number" name="price" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 sm:text-sm bg-white dark:bg-gray-700 dark:border-gray-600">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Cover Letter / Message</label>
                        <textarea name="cover_letter" rows="3" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 sm:text-sm bg-white dark:bg-gray-700 dark:border-gray-600"></textarea>
                    </div>
                    <div id="athProposalMsg" class="text-sm hidden"></div>
                </form>
             `;
        }

        content.innerHTML = html;
        if (typeof feather !== 'undefined') feather.replace();


        // --- ACTIONS RENDER ---
        let btns = '';
        if (isTradie && job.status === 'open') {
            btns = `
                <button onclick="window.ATHJobDetails.submitProposal()" class="inline-flex w-full justify-center rounded-md bg-teal-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-teal-500 sm:ml-3 sm:w-auto">Submit Quote</button>
                <button onclick="window.ATHJobDetails.close()" class="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto">Cancel</button>
            `;
        } else if (!currentUser) {
            btns = `
                <a href="/index.html?action=login&redirect=/pages/jobs.html" class="inline-flex w-full justify-center rounded-md bg-teal-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-teal-500 sm:ml-3 sm:w-auto">Login to Quote</a>
                <button onclick="window.ATHJobDetails.close()" class="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto">Close</button>
            `;
        } else {
             btns = `<button onclick="window.ATHJobDetails.close()" class="mt-3 inline-flex w-full justify-center rounded-md bg-white px-3 py-2 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50 sm:mt-0 sm:w-auto">Close</button>`;
        }
        actions.innerHTML = btns;
    }

    async function loadProposalsForOwner(jobId) {
        const list = document.getElementById('athJobProposalsList');
        if (!list) return;

        const { data: proposals } = await getProposalsForJob(jobId);
        
        if (!proposals || proposals.length === 0) {
            list.innerHTML = `<p class="text-gray-500 italic text-sm">No quotes received yet.</p>`;
            return;
        }

        list.innerHTML = proposals.map(p => `
            <div class="border border-gray-200 dark:border-gray-600 rounded-lg p-3 bg-white dark:bg-gray-800">
                <div class="flex justify-between items-start">
                    <div class="flex items-center gap-2">
                         <img src="${p.tradie?.avatar_url || 'https://via.placeholder.com/32'}" class="w-8 h-8 rounded-full bg-gray-200">
                         <div>
                            <div class="text-sm font-medium text-gray-900 dark:text-white">${escapeHtml(p.tradie?.display_name || 'Tradie')}</div>
                            <div class="text-xs text-teal-600 font-semibold">$${p.price}</div>
                         </div>
                    </div>
                    ${renderProposalStatus(p)}
                </div>
                <div class="mt-2 text-sm text-gray-600 dark:text-gray-300 bg-gray-50 dark:bg-gray-700/50 p-2 rounded">
                    ${escapeHtml(p.cover_letter)}
                </div>
            </div>
        `).join('');
    }

    function renderProposalStatus(p) {
        if (p.status === 'accepted') {
            return `<span class="px-2 py-1 bg-green-100 text-green-800 text-xs font-bold rounded">ACCEPTED</span>`;
        }
        if (currentJob.status !== 'open') {
             // Job closed, can't hire
             return `<span class="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded">${p.status.toUpperCase()}</span>`;
        }
        // Action Button
        return `
            <button onclick="window.ATHJobDetails.acceptProposal('${p.id}')" 
                    class="px-3 py-1 bg-teal-600 text-white text-xs font-medium rounded hover:bg-teal-700">
                Accept
            </button>
        `;
    }

    async function submitProposal() {
        const form = document.getElementById('athProposalForm');
        if (!form) return;
        
        const price = form.price.value;
        const letter = form.cover_letter.value;
        const msg = document.getElementById('athProposalMsg');

        if (!price || !letter) {
            alert('Please fill in all fields');
            return;
        }

        const btn = document.querySelector('#athJobModalActions button'); // primitive selector
        if(btn) { btn.disabled = true; btn.textContent = 'Sending...'; }

        // Create
        const payload = {
            job_id: currentJob.id,
            tradie_id: currentUser.id,
            price: Number(price),
            cover_letter: letter,
            status: 'submitted'
        };

        const { data, error } = await createProposal(payload);
        
        if (error) {
            console.error(error);
            if(msg) { msg.textContent = 'Error sending quote.'; msg.classList.remove('hidden'); msg.classList.add('text-red-600'); }
            if(btn) { btn.disabled = false; btn.textContent = 'Submit Quote'; }
            return;
        }

        if(msg) { msg.textContent = 'Quote sent successfully!'; msg.classList.remove('hidden'); msg.classList.add('text-green-600'); }
        
        // Close after short delay
        setTimeout(() => {
            close();
            // Refresh list if applicable?
        }, 1500);
    }

    async function acceptProposal(proposalId) {
        if (!confirm('Hire this tradie? You will be accurately charged for the quote amount.')) return;

        const btn = document.querySelector('#athJobModalActions button'); // not robust if multiple buttons
        // Better trigger element targeting?
        // We'll proceed with simple blocking interactions.
        
        // 1. Process Payment
        // Ensure Stripe wrapper is loaded
        if (window.ATHStripe && typeof window.ATHStripe.payForJob === 'function') {
             // Mock payment flow
             const result = await window.ATHStripe.payForJob(proposalId, currentJob.id);
             
             if (!result.success) {
                 alert('Payment failed: ' + (result.error || 'Unknown error'));
                 return;
             }
        } else {
             console.warn('Stripe not loaded, bypassing payment for demo...');
        }

        // 2. Update Job Status -> in_progress
        const { error: jErr } = await updateJob(currentJob.id, { 
            status: 'in_progress', 
            assigned_tradie_id: null 
        });

        // 3. Update Proposal Status -> accepted
        const { error: pErr } = await updateProposalStatus(proposalId, 'accepted');

        if (jErr || pErr) {
            alert('Error updating status after payment.');
            console.error(jErr, pErr);
            return;
        }
        
        alert('Payment successful! Tradie hired.');

        // Refresh UI
        open(currentJob.id); 
    }

    function escapeHtml(text) {
        if (!text) return '';
        return String(text)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    return {
        open,
        close,
        submitProposal,
        acceptProposal
    };
})();

// Auto-init? Only if needed on page load.
// We just define it.
